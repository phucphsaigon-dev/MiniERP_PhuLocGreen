ERP_App_Starter Builder (Dashboard + xanh lá + Segoe UI 11pt + Toggle Ribbon)

Cách dùng (Windows + Excel 64-bit):
1) Giải nén thư mục này.
2) Mở file build_starter.vbs (double-click).
3) Script sẽ tạo file ERP_App_Starter.xlsm (tự động ẩn lưới ô, tạo 2 nút: Quản lý Khách hàng & Ẩn/Hiện Ribbon).
4) Mở ERP_App_Starter.xlsm và bật macro để dùng.

Gợi ý folder cuối:
MiniERP_PhuLocGreen/
 ├─ ERP_App_Starter.xlsm
 └─ data/ERP_Data.xlsx

Lưu ý: Nếu muốn ẨN Ribbon mặc định khi mở file, hãy nhấn nút "Ẩn/Hiện Ribbon".
