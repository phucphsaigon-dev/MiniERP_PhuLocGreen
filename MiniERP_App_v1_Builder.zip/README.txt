MiniERP_App_v1 Builder (Dashboard + xanh lá + 64-bit)

Cách dùng (Windows + Excel 64-bit):
1) Giải nén toàn bộ thư mục này ra máy tính (không chạy trực tiếp trong .zip).
2) Mở Windows Explorer, vào thư mục đã giải nén.
3) Nhấp đôi file: build_mini_erp.vbs
   - Script sẽ mở Excel ngầm, tạo sheet Dashboard (A1:C3 tiêu đề xanh lá),
     import 6 module VBA (modConst, modUtil, dalDMKH, bllDMKH, uiDMKH, modStartup),
     thêm nút 'Quản lý Khách hàng', và lưu file: MiniERP_App_v1.xlsm
4) Mở MiniERP_App_v1.xlsm bằng Excel, bấm 'Enable Content' để bật macro.
5) Nhấn nút 'Quản lý Khách hàng' để chạy demo (MsgBox).

Thư mục gợi ý sau khi hoàn tất:
MiniERP_PhuLocGreen/
 ├─ MiniERP_App_v1.xlsm
 ├─ data/
 │   └─ ERP_Data.xlsx (bạn tự thêm)
 ├─ src/ (nếu muốn giữ các module rời)
 └─ ...

Lưu ý bảo mật:
- Để import module bằng script, Excel cần bật 'Trust access to the VBA project object model' (Macro Settings).
  Cách bật: Excel → Options → Trust Center → Trust Center Settings → Macro Settings → tick ô này.

© 2025 Phu Lộc Green Environment JSC
