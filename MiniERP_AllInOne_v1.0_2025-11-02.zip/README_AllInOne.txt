MiniERP_AllInOne_v1.0_2025-11-02

Cách dùng:
1) Giải nén gói.
2) Chạy: builders/ERP_App_Starter/build_app_v1.vbs
3) Script sẽ tạo ERP_App_Starter_v1.0.xlsm trong thư mục gốc gói.
4) Mở file .xlsm → Enable Macro → dùng 3 nút trên Dashboard.

Yêu cầu: bật "Trust access to the VBA project object model" trong Excel.
