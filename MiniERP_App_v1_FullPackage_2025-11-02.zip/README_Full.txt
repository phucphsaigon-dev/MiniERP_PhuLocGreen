MiniERP_App_v1_FullPackage_2025-11-02

✅ Bao gồm:
- MiniERP_App_v1_Builder (VBS + 6 module VBA)
- data/ERP_Data.xlsx (2 sheet: tblDMKH + __CFG)

📋 Cách dùng:
1. Giải nén toàn bộ gói.
2. Vào thư mục MiniERP_App_v1_Builder, nhấp đôi build_mini_erp.vbs.
3. Script tự tạo file MiniERP_App_v1.xlsm.
4. Mở Excel, bật macro, kiểm tra sheet Dashboard.

© 2025 Phu Lộc Green Environment JSC
