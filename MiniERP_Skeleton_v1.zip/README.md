# MiniERP – PhuLoc Green Environment JSC

### 📘 Tổng quan
MiniERP là hệ thống ERP gọn nhẹ được phát triển cho doanh nghiệp vừa và nhỏ, đặc biệt trong lĩnh vực năng lượng mặt trời và môi trường.

### 🧱 Kiến trúc
- **70% Excel + VBA:** giao diện chính, xử lý nghiệp vụ.
- **30% Python / SQL / .NET:** phục vụ tự động hóa, phân tích, kết nối CSDL.

### 📁 Thành phần chính
- `src/vba` : Mã nguồn VBA (DAL, BLL, UI)
- `src/python` : Script hỗ trợ Excel & xuất dữ liệu
- `data/` : CSDL Excel, SQLite
- `templates/` : Biểu mẫu Word/Excel xuất ra từ hệ thống
- `docs/` : Đặc tả & hướng dẫn kỹ thuật

### 🚀 Cách khởi động
1. Mở `ERP_App.xlsm`
2. Chạy macro `init_setup`
3. Kiểm tra file `ERP_Data.xlsx` kết nối thành công
4. Thực hiện thao tác mẫu: Quản lý khách hàng (`frmDMKH`)

---

© 2025 PhuLoc Green Environment JSC  
Liên hệ: **www.phulocgreen.com | dunglocphat@gmail.com**