-- Cấu trúc CSDL MiniERP
CREATE TABLE tblDMKH (
    MaKH TEXT PRIMARY KEY,
    TenKH TEXT,
    DiaChi TEXT,
    DienThoai TEXT
);