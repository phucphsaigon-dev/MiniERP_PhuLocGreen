-- Dữ liệu mẫu cho Danh Mục Khách Hàng
INSERT INTO tblDMKH (MaKH, TenKH, DiaChi, DienThoai) VALUES
('KH0001', 'Công ty TNHH ABC', 'Hà Nội', '0901234567'),
('KH0002', 'Công ty CP XYZ', 'TP.HCM', '0907654321');